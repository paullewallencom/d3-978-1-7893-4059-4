var colors = ['white', 'red', 'green', 'blue', 'black'];

